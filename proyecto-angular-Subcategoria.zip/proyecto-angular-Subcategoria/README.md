Proyecto marketplace con angular y firebase
El proyecto consta de una plantilla html,css y js.
![image](https://github.com/user-attachments/assets/ca427821-5065-418b-b092-8fb86435ac6c)
[![My Skills](https://skillicons.dev/icons?i=js,html,css,wasm)](https://skillicons.dev)
ANGULAR
