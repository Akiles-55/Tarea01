// Exportamos la ruta para las imagenes
export let Path = {
    url: "http://localhost:4200/assets/"
}

// Exportamos el endpoint de la apirest de firebase
export let Api = {
    url: 'https://marketplace-8450b-default-rtdb.firebaseio.com/' //endpoint de firebase
}