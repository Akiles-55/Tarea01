import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Api } from '../config';
import { Observable } from 'rxjs';
import { map } from 'rxjs';
import { response } from 'express';

@Injectable({
  providedIn: 'root'
})
export class CategoriesService {

  private api:String = Api.url;

  constructor(private http:HttpClient) { }

  getData(): Observable<any>{
    return this.http.get(`${this.api}categories.json`).pipe(
      map((response: any) => Object.values(response)) // convertir un objeto a un array
    );
  }

}
