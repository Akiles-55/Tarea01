import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { HeaderComponent } from "./modules/header/header.component";
import { HeaderPromotionComponent } from "./modules/header-promotion/header-promotion.component";
import { HeaderMobileComponent } from "./modules/header-mobile/header-mobile.component";
import { NewletterComponent } from "./modules/newletter/newletter.component";
import { FooterComponent } from "./modules/footer/footer.component";

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    RouterOutlet, 
    HeaderComponent, 
    HeaderPromotionComponent, 
    HeaderMobileComponent, 
    NewletterComponent, 
    FooterComponent
  ],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'angular-proyect';
}
