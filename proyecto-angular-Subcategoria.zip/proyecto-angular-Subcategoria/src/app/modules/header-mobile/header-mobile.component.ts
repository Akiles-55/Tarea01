import { Component, OnInit } from '@angular/core';
import { Path } from '../../config';

@Component({
  selector: 'app-header-mobile',
  imports: [],
  templateUrl: './header-mobile.component.html',
  styleUrl: './header-mobile.component.css'
})
export class HeaderMobileComponent implements OnInit{
  path:String = Path.url;
  constructor() {}
  ngOnInit(): void {
    
  }
}
