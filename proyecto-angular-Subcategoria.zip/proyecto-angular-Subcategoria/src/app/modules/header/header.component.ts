import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CategoriesService } from '../../services/categories.service';
import { SubCategoriesService } from '../../services/sub-categories.service';
import { Path } from '../../config';

@Component({
  selector: 'app-header',
  imports: [CommonModule],
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  path: string = Path.url;
  categories: any[] = [];
  subcategories: any[] = [];

  constructor(
    private categoriesService: CategoriesService,
    private subcategoriesService: SubCategoriesService
  ) {}

  ngOnInit(): void {
    // Traer la data de categorías
    this.categoriesService.getData().subscribe((resp) => {
      // console.log("Categorias : ", resp);
      this.categories = resp;
    });

    // Traer la data de subcategorías
    this.subcategoriesService.getData().subscribe((resp) => {
      // console.log("Subcategorias : ", resp);
      this.subcategories = resp;
    });
  }

  // Función para obtener las subcategorías de una categoría específica
  getSubcategories(categoryName: string) {
    return this.subcategories.filter(subcategory => subcategory.category === categoryName);
  }
}
