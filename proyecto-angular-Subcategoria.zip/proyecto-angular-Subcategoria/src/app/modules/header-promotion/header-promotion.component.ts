import { Component, OnInit } from '@angular/core';
import { Path } from '../../config';
import { ProductsService } from '../../services/products.service';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-header-promotion',
  standalone: true,
  imports: [HttpClientModule,CommonModule],
  templateUrl: './header-promotion.component.html',
  styleUrls: ['./header-promotion.component.css']
})
export class HeaderPromotionComponent implements OnInit{
  path:String = Path.url;
  top_banner:any;
  preload:Boolean = false;
  constructor(private productsService: ProductsService) {}
  ngOnInit(): void {
    this.productsService.getData()
        .subscribe(resp => {
          // console.log("resp", resp);
          let i, size = 0;
          for(i in resp){
            size++;
          }
          // console.log("size",size);
          // generar un número aleatorio
          let index = Math.floor(Math.random()*size);
          // devolver la vista al banner aleatorio
          this.top_banner = JSON.parse(resp[Object.keys(resp)[index]].top_banner);
          this.preload = false;
        })
  }
}
